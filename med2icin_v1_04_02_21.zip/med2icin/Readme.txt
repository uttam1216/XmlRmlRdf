#Keep all files in a folder and open a terminal and run the following command:
python transform_inp_xml_to_rml.py
#all necessary files will run in auto. Basically, running this, takes all input files from the 'input_files' folder
#and then creates RML rules for each in an intermediate folder and then runs them for output. 
#The output once generated, are formated in auto by call of a function in format_intermediate_out.py script called by itself.
